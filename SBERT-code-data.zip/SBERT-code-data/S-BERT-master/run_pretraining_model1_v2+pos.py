# coding=utf-8
# Copyright 2018 The Google AI Language Team Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Run masked LM/next sentence masked_lm pre-training for BERT."""

'''
     文件 说明： 是想 解决 注意力 机制 的 位置 编码 问题。 想 通过 拼接位置 编码的方式 来解决， 没成功

'''

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import modeling
import optimization
import tensorflow as tf

import numpy as np

flags = tf.flags

FLAGS = flags.FLAGS

## Required parameters
flags.DEFINE_string(
    "bert_config_file", "chinese_L-12_H-768_A-12\\bert_config.json",
    "The config json file corresponding to the pre-trained BERT model. "
    "This specifies the model architecture.")

flags.DEFINE_string(
    "input_file", " sents4trainBERT_4_model_1",  # sents4trainBERT00,sents4trainBERT01
    "Input TF example files (can be a glob or comma separated).")

flags.DEFINE_string(
    "output_dir", "pretrain_output",
    "The output directory where the model checkpoints will be written.")

## Other parameters
flags.DEFINE_string(
    "init_checkpoint", "chinese_L-12_H-768_A-12\\bert_model.ckpt",
    # chinese_L-12_H-768_A-12\\bert_model.ckpt #"pretrain_output"#pretrain_output_sents_BERT_wiki
    "Initial checkpoint (usually from a pre-trained BERT model).")

flags.DEFINE_integer(
    "max_seq_length", 128,
    "The maximum total input sequence length after WordPiece tokenization. "
    "Sequences longer than this will be truncated, and sequences shorter "
    "than this will be padded. Must match data generation.")

flags.DEFINE_integer(
    "max_predictions_per_seq", 20,
    "Maximum number of masked LM predictions per sequence. "
    "Must match data generation.")

flags.DEFINE_bool("do_train", True, "Whether to run training.")

flags.DEFINE_bool("do_eval", False, "Whether to run eval on the dev set.")

flags.DEFINE_integer("train_batch_size", 2, "Total batch size for training.")

flags.DEFINE_integer("eval_batch_size", 8, "Total batch size for eval.")

flags.DEFINE_float("learning_rate", 5e-5, "The initial learning rate for Adam.")

flags.DEFINE_integer("num_train_steps", 600000, "Number of training steps.")

flags.DEFINE_integer("num_warmup_steps", 12000, "Number of warmup steps.")

flags.DEFINE_integer("save_checkpoints_steps", 4000,
                     "How often to save the model checkpoint.")

flags.DEFINE_integer("iterations_per_loop", 1000,
                     "How many steps to make in each estimator call.")

flags.DEFINE_integer("max_eval_steps", 100, "Maximum number of eval steps.")

flags.DEFINE_bool("use_tpu", False, "Whether to use TPU or GPU/CPU.")

tf.flags.DEFINE_string(
    "tpu_name", None,
    "The Cloud TPU to use for trai ning. This should be either the name "
    "used when creating the Cloud TPU, or a grpc://ip.address.of.tpu:8470 "
    "url.")

tf.flags.DEFINE_string(
    "tpu_zone", None,
    "[Optional] GCE zone where the Cloud TPU is located in. If not "
    "specified, we will attempt to automatically detect the GCE project from "
    "metadata.")

tf.flags.DEFINE_string(
    "gcp_project", None,
    "[Optional] Project name for the Cloud TPU-enabled project. If not "
    "specified, we will attempt to automatically detect the GCE project from "
    "metadata.")

tf.flags.DEFINE_string("master", None, "[Optional] TensorFlow master URL.")

flags.DEFINE_integer(
    "num_tpu_cores", 8,
    "Only used if `use_tpu` is True. Total number of TPU cores to use.")


def get_pos_num(num):
    if num < 0:
        return -1, -1, -1

    baiwei = int(num / 100)
    shiwei = int((num - baiwei * 100) / 10)
    gewei = num % 10

    if baiwei > 0:
        return gewei, shiwei, baiwei

    else:  # 百位为0
        if shiwei > 0:
            return gewei, shiwei, -1
        else:  # 十位为 0
            return gewei, -1, -1

    return gewei, shiwei, baiwei


def getPositionEmbedding(len=128):
    posarr = np.zeros((128, 22), dtype=np.int32)  # 采用十进制的位置编码方式

    for i in range(len):
        g, s, b = get_pos_num(i)
        posarr[i, g] = 1
        if s >= 0:
            posarr[i, s + 10] = 1

        if b >= 0:
            posarr[i, b + 20] = 1

    pos = tf.constant(posarr, dtype=tf.float32)

    return pos


def model_fn_builder(bert_config, init_checkpoint, learning_rate,
                     num_train_steps, num_warmup_steps, use_tpu,
                     use_one_hot_embeddings):
    """Returns `model_fn` closure for TPUEstimator."""

    def model_fn(features, labels, mode, params):  # pylint: disable=unused-argument
        """The `model_fn` for TPUEstimator."""

        tf.logging.info("*** Features ***")
        for name in sorted(features.keys()):
            tf.logging.info("  name = %s, shape = %s" % (name, features[name].shape))

        input_ids = features["input_ids"]
        input_mask = features["input_mask"]
        segment_ids = features["segment_ids"]
        masked_lm_positions = features["masked_lm_positions"]
        masked_lm_ids = features["masked_lm_ids"]
        masked_lm_weights = features["masked_lm_weights"]
        next_sentence_labels = features["next_sentence_labels"]
        # actual_words = features["actual_words"]

        sa_mask = features["sa_mask"]
        sb_mask = features["sb_mask"]
        pred_word = features["pred_word"]
        pred_word_weights = features["pred_word_weights"]

        is_training = (mode == tf.estimator.ModeKeys.TRAIN)

        model = modeling.BertModel(
            config=bert_config,
            is_training=is_training,
            input_ids=input_ids,
            input_mask=input_mask,
            token_type_ids=segment_ids,
            use_one_hot_embeddings=use_one_hot_embeddings)

        (masked_lm_loss,
         masked_lm_example_loss, masked_lm_log_probs) = get_masked_lm_output(
            bert_config, model.get_sequence_output(), model.get_embedding_table(),
            masked_lm_positions, masked_lm_ids, masked_lm_weights)

        (next_sentence_loss, next_sentence_example_loss,
         next_sentence_log_probs) = get_next_sentence_output(
            bert_config, model.get_pooled_output(), next_sentence_labels)

        bert_out = model.get_sequence_output()
        shape = modeling.get_shape_list(bert_out, expected_rank=3)
        batch_size = shape[0]
        max_seq_length = shape[1]

        # bert_config, bert_out, sa_mask, sb_mask, pred_wrods, pred_word_weight, embedding_table, batch_size, max_seq_length
        sents_loss = get_predict_words_loss(bert_config, bert_out,
                                            sa_mask, sb_mask, pred_word, pred_word_weights,
                                            model.get_embedding_table(),
                                            batch_size, max_seq_length)

        total_loss = masked_lm_loss + next_sentence_loss + sents_loss

        tvars = tf.trainable_variables()

        initialized_variable_names = {}
        scaffold_fn = None
        if init_checkpoint:
            (assignment_map, initialized_variable_names
             ) = modeling.get_assignment_map_from_checkpoint(tvars, init_checkpoint)
            if use_tpu:

                def tpu_scaffold():
                    tf.train.init_from_checkpoint(init_checkpoint, assignment_map)
                    return tf.train.Scaffold()

                scaffold_fn = tpu_scaffold
            else:
                tf.train.init_from_checkpoint(init_checkpoint, assignment_map)

        tf.logging.info("**** Trainable Variables ****")
        for var in tvars:
            init_string = ""
            if var.name in initialized_variable_names:
                init_string = ", *INIT_FROM_CKPT*"
            tf.logging.info("  name = %s, shape = %s%s", var.name, var.shape,
                            init_string)

        output_spec = None
        if mode == tf.estimator.ModeKeys.TRAIN:
            train_op = optimization.create_optimizer(
                total_loss, learning_rate, num_train_steps, num_warmup_steps, use_tpu)

            logging_hook = tf.train.LoggingTensorHook(
                {"loss": total_loss, "sent_loss": sents_loss, "lm_loss": masked_lm_loss,
                 "ns_loss": next_sentence_loss}, every_n_iter=1000)

            output_spec = tf.contrib.tpu.TPUEstimatorSpec(
                mode=mode,
                loss=total_loss,
                train_op=train_op,
                scaffold_fn=scaffold_fn,
                training_hooks=[logging_hook])
        elif mode == tf.estimator.ModeKeys.EVAL:

            def metric_fn(masked_lm_example_loss, masked_lm_log_probs, masked_lm_ids,
                          masked_lm_weights, next_sentence_example_loss,
                          next_sentence_log_probs, next_sentence_labels):
                """Computes the loss and accuracy of the model."""
                masked_lm_log_probs = tf.reshape(masked_lm_log_probs,
                                                 [-1, masked_lm_log_probs.shape[-1]])
                masked_lm_predictions = tf.argmax(
                    masked_lm_log_probs, axis=-1, output_type=tf.int32)
                masked_lm_example_loss = tf.reshape(masked_lm_example_loss, [-1])
                masked_lm_ids = tf.reshape(masked_lm_ids, [-1])
                masked_lm_weights = tf.reshape(masked_lm_weights, [-1])
                masked_lm_accuracy = tf.metrics.accuracy(
                    labels=masked_lm_ids,
                    predictions=masked_lm_predictions,
                    weights=masked_lm_weights)
                masked_lm_mean_loss = tf.metrics.mean(
                    values=masked_lm_example_loss, weights=masked_lm_weights)

                next_sentence_log_probs = tf.reshape(
                    next_sentence_log_probs, [-1, next_sentence_log_probs.shape[-1]])
                next_sentence_predictions = tf.argmax(
                    next_sentence_log_probs, axis=-1, output_type=tf.int32)
                next_sentence_labels = tf.reshape(next_sentence_labels, [-1])
                next_sentence_accuracy = tf.metrics.accuracy(
                    labels=next_sentence_labels, predictions=next_sentence_predictions)
                next_sentence_mean_loss = tf.metrics.mean(
                    values=next_sentence_example_loss)

                return {
                    "masked_lm_accuracy": masked_lm_accuracy,
                    "masked_lm_loss": masked_lm_mean_loss,
                    "next_sentence_accuracy": next_sentence_accuracy,
                    "next_sentence_loss": next_sentence_mean_loss,
                }

            eval_metrics = (metric_fn, [
                masked_lm_example_loss, masked_lm_log_probs, masked_lm_ids,
                masked_lm_weights, next_sentence_example_loss,
                next_sentence_log_probs, next_sentence_labels
            ])
            output_spec = tf.contrib.tpu.TPUEstimatorSpec(
                mode=mode,
                loss=total_loss,
                eval_metrics=eval_metrics,
                scaffold_fn=scaffold_fn)
        else:
            raise ValueError("Only TRAIN and EVAL modes are supported: %s" % (mode))

        return output_spec

    return model_fn


'''
函数功能：求 被 “遮盖”的 单词 的 loss
参数说明：
          bert_config，BERT的配置信息；
          input_tensor，BERT 最后一层的输出，对应于 BERT.get_sequence_out()
          output_weights, 词表中每个词对应的 Embedding
          positions，被“遮盖”单词的位置，masked_lm_positions
          label_ids，被“遮盖”单词的id, masked_lm_ids
          label_weights, A tensor has a value of 1.0 for every real prediction and 0.0 for the padding predictions.

返回值：(loss, per_example_loss, log_probs)
'''


def get_masked_lm_output(bert_config, input_tensor, output_weights, positions,
                         label_ids, label_weights):
    """Get loss and log probs for the masked LM."""
    input_tensor = gather_indexes(input_tensor, positions)  # shape=(num_of_masked, embedding_size)

    with tf.variable_scope("cls/predictions"):
        # We apply one more non-linear transformation before the output layer.
        # This matrix is not used after pre-training.
        with tf.variable_scope("transform"):
            input_tensor = tf.layers.dense(
                input_tensor,
                units=bert_config.hidden_size,
                activation=modeling.get_activation(bert_config.hidden_act),
                kernel_initializer=modeling.create_initializer(
                    bert_config.initializer_range))
            input_tensor = modeling.layer_norm(input_tensor)

        # The output weights are the same as the input embeddings, but there is
        # an output-only bias for each token.
        output_bias = tf.get_variable(
            "output_bias",
            shape=[bert_config.vocab_size],
            initializer=tf.zeros_initializer())
        logits = tf.matmul(input_tensor, output_weights, transpose_b=True)
        logits = tf.nn.bias_add(logits, output_bias)
        log_probs = tf.nn.log_softmax(logits, axis=-1)

        label_ids = tf.reshape(label_ids, [-1])
        label_weights = tf.reshape(label_weights, [-1])

        one_hot_labels = tf.one_hot(
            label_ids, depth=bert_config.vocab_size, dtype=tf.float32)

        # The `positions` tensor might be zero-padded (if the sequence is too
        # short to have the maximum number of predictions). The `label_weights`
        # tensor has a value of 1.0 for every real prediction and 0.0 for the
        # padding predictions.
        per_example_loss = -tf.reduce_sum(log_probs * one_hot_labels, axis=[-1])
        numerator = tf.reduce_sum(label_weights * per_example_loss)
        denominator = tf.reduce_sum(label_weights) + 1e-5
        loss = numerator / denominator

    return (loss, per_example_loss, log_probs)


'''
函数功能：获得 预测下一句的 loss
参数说明：
           bert_config, BERT 的配置参数
           input_tensor，BERT的get_pooled_output()，shape=(batchsize, Embedding_size)
           labels, 是否是 下一句的标签，             shape=(batchsize, )

返回值：(loss, per_example_loss, log_probs)
'''


def get_next_sentence_output(bert_config, input_tensor, labels):
    """Get loss and log probs for the next sentence prediction."""

    # Simple binary classification. Note that 0 is "next sentence" and 1 is
    # "random sentence". This weight matrix is not used after pre-training.
    with tf.variable_scope("cls/seq_relationship"):
        output_weights = tf.get_variable(
            "output_weights",
            shape=[2, bert_config.hidden_size],
            initializer=modeling.create_initializer(bert_config.initializer_range))  # trainable=None 或 True，表示可训练的
        output_bias = tf.get_variable(
            "output_bias", shape=[2], initializer=tf.zeros_initializer())  # trainable=None 或 True，表示可训练的

        logits = tf.matmul(input_tensor, output_weights, transpose_b=True)
        logits = tf.nn.bias_add(logits, output_bias)
        log_probs = tf.nn.log_softmax(logits, axis=-1)  # logits.shape = (batchsize, 2)
        labels = tf.reshape(labels, [-1])
        one_hot_labels = tf.one_hot(labels, depth=2, dtype=tf.float32)
        per_example_loss = -tf.reduce_sum(one_hot_labels * log_probs, axis=-1)
        loss = tf.reduce_mean(per_example_loss)
        return (loss, per_example_loss, log_probs)


def get_predict_words_loss(bert_config, bert_out, sa_mask, sb_mask, pred_wrods, pred_word_weight, embedding_table,
                           batch_size, max_seq_length):
    index = tf.range(start=0, limit=batch_size, dtype=tf.int32)
    index = tf.reshape(index, (batch_size, 1))
    index = tf.tile(index, [1, max_seq_length])
    index = tf.reshape(index, (batch_size * max_seq_length,))

    # 把实际需要计算的例子 挑选 出来
    act_batchsize = tf.cast(tf.reduce_sum(pred_word_weight), tf.int32)
    act_mask = tf.reshape(tf.where(tf.reshape(pred_word_weight, [-1])), [-1])  # 把坐标搞出来，不用原来的for循环

    sa_mask = tf.reshape(sa_mask, (-1, max_seq_length))  # (batch_size * max_seq_length, max_seq_length)
    sb_mask = tf.reshape(sb_mask, (-1, max_seq_length))  # (batch_size * max_seq_length, max_seq_length)

    sa_mask = tf.gather(sa_mask, act_mask)  # 筛选出 实际的 sa_mask
    sb_mask = tf.gather(sb_mask, act_mask)  # 筛选出 实际的 sb_mask

    pred_wrods = tf.reshape(pred_wrods, (batch_size * max_seq_length,))  # (batch_size * max_seq_length, )
    pred_word_weight = tf.reshape(pred_word_weight, (batch_size * max_seq_length,))  # (batch_size * max_seq_length, )

    pred_wrods = tf.gather(pred_wrods, act_mask)
    pred_word_weight = tf.gather(pred_word_weight, act_mask)

    bert_out = tf.gather(tf.gather(bert_out, index), act_mask)  # 把上面的操作 合并，省空间

    query_a, query_b = attenion_1_model2_v2(bert_config, bert_out, act_batchsize, max_seq_length, sa_mask, sb_mask)

    sents_a_representation = self_attention_v2(bert_config, query_a, bert_out, sa_mask, act_batchsize, max_seq_length)
    sents_b_representation = self_attention_v2(bert_config, query_b, bert_out, sb_mask, act_batchsize, max_seq_length)

    delta_representation = sents_b_representation - sents_a_representation

    with tf.variable_scope("sentsBERT/predictions"):
        # We apply one more non-linear transformation before the output layer.
        # This matrix is not used after pre-training.
        with tf.variable_scope("transform"):
            input_tensor = tf.layers.dense(
                delta_representation,
                units=bert_config.hidden_size,
                activation=modeling.get_activation(bert_config.hidden_act),
                kernel_initializer=modeling.create_initializer(
                    bert_config.initializer_range))
            input_tensor = modeling.layer_norm(input_tensor)

        # The output weights are the same as the input embeddings, but there is
        # an output-only bias for each token.
        output_bias = tf.get_variable(
            "output_bias",
            shape=[bert_config.vocab_size],
            initializer=tf.zeros_initializer())
        logits = tf.matmul(input_tensor, embedding_table, transpose_b=True)
        logits = tf.nn.bias_add(logits, output_bias)
        log_probs = tf.nn.log_softmax(logits, axis=-1)

        one_hot_labels = tf.one_hot(pred_wrods, depth=bert_config.vocab_size, dtype=tf.float32)

        # The `positions` tensor might be zero-padded (if the sequence is too
        # short to have the maximum number of predictions). The `label_weights`
        # tensor has a value of 1.0 for every real prediction and 0.0 for the
        # padding predictions.
        per_example_loss = -tf.reduce_sum(log_probs * one_hot_labels, axis=[-1])  # 记得 加 符号
        numerator = tf.reduce_sum(pred_word_weight * per_example_loss)
        denominator = tf.reduce_sum(pred_word_weight) + 1e-5
        loss = numerator / denominator

    # return (loss, per_example_loss, log_probs)
    return loss


'''
def attenion_1(bert_config, x_a, x_b, batch_size, max_seq_length, mask_a=None, mask_b=None):
    with tf.variable_scope("attention/sentsBERT/predictions"):
        W = tf.get_variable(
            "query_vector_W",
            shape=[bert_config.hidden_size, bert_config.hidden_size],
            initializer=tf.random_normal_initializer(mean=0, stddev=bert_config.initializer_range))

        b = tf.get_variable(
            "query_vector_b",
            shape=[bert_config.hidden_size],
            initializer=tf.zeros_initializer)

    W_ = tf.reshape(W, (1, bert_config.hidden_size, bert_config.hidden_size))
    W_ = tf.tile(W_, [batch_size * max_seq_length, 1, 1])

    # ================ calc query_a =========

    uit = tf.matmul(x_a, W_)
    uit += b
    uit = tf.tanh(uit)
    a = tf.exp(uit)

    if mask_a is not None:
        # dim = bert_config.hidden_size
        # mask_matrix = tf.cast(tf.tile(tf.expand_dims(mask, axis=2), [1, 1, dim]), tf.float32) # 数据类型 一定要 一样， 否则 出错
        # 上面可以用下面的广播机制代替
        a *= tf.cast(tf.expand_dims(mask_a, axis=2), tf.float32)

    epsilon = 1e-8

    a /= tf.cast(tf.reduce_sum(a, axis=1, keepdims=True) + epsilon, tf.float32)
    weighted_input = x_a * a
    query_a = tf.reduce_sum(weighted_input, axis=1)

    # ================= calc query_b ====================

    uit = tf.matmul(x_b, W_)
    uit += b
    uit = tf.tanh(uit)
    a = tf.exp(uit)

    if mask_b is not None:
        a *= tf.cast(tf.expand_dims(mask_b, axis=2), tf.float32)

    a /= tf.cast(tf.reduce_sum(a, axis=1, keepdims=True) + epsilon, tf.float32)
    weighted_input = x_b * a
    query_b = tf.reduce_sum(weighted_input, axis=1)

    return query_a, query_b
'''


def attenion_1_model2_v2(bert_config, x, act_batchsize, max_seq_length, mask_a=None, mask_b=None):
    with tf.variable_scope("attention/sentsBERT/predictions"):
        W = tf.get_variable(
            "query_vector_W",
            shape=[bert_config.hidden_size, bert_config.hidden_size],
            initializer=tf.random_normal_initializer(mean=0, stddev=bert_config.initializer_range))

        b = tf.get_variable(
            "query_vector_b",
            shape=[bert_config.hidden_size],
            initializer=tf.zeros_initializer)

    W_ = tf.reshape(W, (1, bert_config.hidden_size, bert_config.hidden_size))
    W_ = tf.tile(W_, [act_batchsize, 1, 1])
    epsilon = 1e-8

    # ================ calc query_a =========

    uit = tf.matmul(x, W_)
    uit += b
    uit = tf.tanh(uit)
    ta = tf.exp(uit)

    a_a = None

    if mask_a is not None:
        # dim = bert_config.hidden_size
        # mask_matrix = tf.cast(tf.tile(tf.expand_dims(mask, axis=2), [1, 1, dim]), tf.float32) # 数据类型 一定要 一样， 否则 出错
        # 上面可以用下面的广播机制代替
        a_a = ta * tf.cast(tf.expand_dims(mask_a, axis=2), tf.float32)

    a_a /= tf.cast(tf.reduce_sum(a_a, axis=1, keepdims=True) + epsilon, tf.float32)
    weighted_input = x * a_a
    query_a = tf.reduce_sum(weighted_input, axis=1)

    # ================= calc query_b ====================
    a_b = None
    if mask_b is not None:
        a_b = ta * tf.cast(tf.expand_dims(mask_b, axis=2), tf.float32)

    a_b /= tf.cast(tf.reduce_sum(a_b, axis=1, keepdims=True) + epsilon, tf.float32)
    weighted_input = x * a_b
    query_b = tf.reduce_sum(weighted_input, axis=1)

    return query_a, query_b


'''
def self_attention(bert_config, query, x, x_mask, batch_size, max_seq_length):
    # query.shape = (batch_size, embedding_size)
    # x.shape = (batch_size,time_step, embedding_size)
    embedding_size = bert_config.hidden_size

    query = tf.reshape(query, (batch_size * max_seq_length, 1, embedding_size))

    m = tf.matmul(query, x, transpose_b=True)

    m = tf.reshape(m, (batch_size * max_seq_length, max_seq_length))

    # m = tf.clip_by_value(m, -20, 25)
    m = tf.tanh(m)

    m = tf.exp(m)

    m = m * tf.cast(x_mask, tf.float32)

    epsilon = 1e-8

    m /= (tf.reduce_sum(m, axis=1, keepdims=True) + epsilon)

    m = tf.expand_dims(m, axis=-1)

    weighted_input = x * m

    return tf.reduce_sum(weighted_input, axis=1)
'''


def self_attention_v2(bert_config, query, x, x_mask, act_batchsize, max_seq_length):
    # query.shape = (batch_size, embedding_size)
    # x.shape = (batch_size,time_step, embedding_size)
    embedding_size = bert_config.hidden_size

    query = tf.reshape(query, (act_batchsize, 1, embedding_size))

    m = tf.matmul(query, x, transpose_b=True)

    m = tf.reshape(m, (act_batchsize, max_seq_length))

    # m = tf.clip_by_value(m, -20, 25)
    m = tf.tanh(m)

    m = tf.exp(m)

    m = m * tf.cast(x_mask, tf.float32)

    epsilon = 1e-8

    m /= (tf.reduce_sum(m, axis=1, keepdims=True) + epsilon)

    m = tf.expand_dims(m, axis=-1)

    pos = getPositionEmbedding(128)
    pos = tf.reshape(pos, (1, 128, 22))
    pos = tf.tile(pos, [act_batchsize, 1, 1])
    newx = tf.concat([x, pos], axis=-1)

    weighted_input = newx * m

    return tf.reduce_sum(weighted_input, axis=1)


'''
函数功能：收集 被“遮盖”位置的 单词向量（注：这个向量是 BERT的最后一层的输出）
参数说明：sequence_tensor，BERT最后一层的输出，shape=(batch,sentence_length,embeding_size)
          positions, 被“遮盖”的位置，这个位置是每个sentence中的相对位置。

返回值：被“遮盖”单词的词向量。shape=(num, embeding_size)

'''


def gather_indexes(sequence_tensor, positions):
    """Gathers the vectors at the specific positions over a minibatch."""
    sequence_shape = modeling.get_shape_list(sequence_tensor, expected_rank=3)
    batch_size = sequence_shape[0]
    seq_length = sequence_shape[1]
    width = sequence_shape[2]

    flat_offsets = tf.reshape(
        tf.range(0, batch_size, dtype=tf.int32) * seq_length, [-1, 1])
    flat_positions = tf.reshape(positions + flat_offsets, [-1])
    flat_sequence_tensor = tf.reshape(sequence_tensor,
                                      [batch_size * seq_length, width])
    output_tensor = tf.gather(flat_sequence_tensor, flat_positions)
    return output_tensor


def input_fn_builder(input_files,
                     max_seq_length,
                     max_predictions_per_seq,
                     is_training,
                     num_cpu_threads=4):
    """Creates an `input_fn` closure to be passed to TPUEstimator."""

    def input_fn(params):
        """The actual input function."""
        batch_size = params["batch_size"]

        name_to_features = {
            "input_ids":
                tf.FixedLenFeature([max_seq_length], tf.int64),
            "input_mask":
                tf.FixedLenFeature([max_seq_length], tf.int64),
            "segment_ids":
                tf.FixedLenFeature([max_seq_length], tf.int64),
            "masked_lm_positions":
                tf.FixedLenFeature([max_predictions_per_seq], tf.int64),
            "masked_lm_ids":
                tf.FixedLenFeature([max_predictions_per_seq], tf.int64),
            "masked_lm_weights":
                tf.FixedLenFeature([max_predictions_per_seq], tf.float32),
            "next_sentence_labels": tf.FixedLenFeature([1], tf.int64),
            # "actual_words": tf.FixedLenFeature([max_seq_length], tf.int64),
            # "sents_a": tf.FixedLenFeature([max_seq_length*max_seq_length], tf.int64),
            # "sents_b": tf.FixedLenFeature([max_seq_length*max_seq_length], tf.int64),
            "pred_word": tf.FixedLenFeature([max_seq_length], tf.int64),
            "sa_mask": tf.FixedLenFeature([max_seq_length * max_seq_length], tf.int64),
            "sb_mask": tf.FixedLenFeature([max_seq_length * max_seq_length], tf.int64),
            "pred_word_weights": tf.FixedLenFeature([max_seq_length], tf.float32),
        }

        # For training, we want a lot of parallel reading and shuffling.
        # For eval, we want no shuffling and parallel reading doesn't matter.
        if is_training:
            d = tf.data.Dataset.from_tensor_slices(tf.constant(input_files))
            d = d.repeat()
            d = d.shuffle(buffer_size=len(input_files))

            # `cycle_length` is the number of parallel files that get read.
            cycle_length = min(num_cpu_threads, len(input_files))

            # `sloppy` mode means that the interleaving is not exact. This adds
            # even more randomness to the training pipeline.
            d = d.apply(
                tf.contrib.data.parallel_interleave(
                    tf.data.TFRecordDataset,
                    sloppy=is_training,
                    cycle_length=cycle_length))
            d = d.shuffle(buffer_size=100)
        else:
            d = tf.data.TFRecordDataset(input_files)
            # Since we evaluate for a fixed number of steps we don't want to encounter
            # out-of-range exceptions.
            d = d.repeat()

        # We must `drop_remainder` on training because the TPU requires fixed
        # size dimensions. For eval, we assume we are evaluating on the CPU or GPU
        # and we *don't* want to drop the remainder, otherwise we wont cover
        # every sample.
        d = d.apply(
            tf.contrib.data.map_and_batch(
                lambda record: _decode_record(record, name_to_features),
                batch_size=batch_size,
                num_parallel_batches=num_cpu_threads,
                drop_remainder=True))
        return d

    return input_fn


def _decode_record(record, name_to_features):
    """Decodes a record to a TensorFlow example."""
    example = tf.parse_single_example(record, name_to_features)

    # tf.Example only supports tf.int64, but the TPU only supports tf.int32.
    # So cast all int64 to int32.
    for name in list(example.keys()):
        t = example[name]
        if t.dtype == tf.int64:
            t = tf.to_int32(t)
        example[name] = t

    return example


def main(_):
    tf.logging.set_verbosity(tf.logging.INFO)

    if not FLAGS.do_train and not FLAGS.do_eval:
        raise ValueError("At least one of `do_train` or `do_eval` must be True.")

    bert_config = modeling.BertConfig.from_json_file(FLAGS.bert_config_file)

    tf.gfile.MakeDirs(FLAGS.output_dir)

    input_files = []
    for input_pattern in FLAGS.input_file.split(","):
        input_files.extend(tf.gfile.Glob(input_pattern))

    tf.logging.info("*** Input Files ***")
    for input_file in input_files:
        tf.logging.info("  %s" % input_file)

    tpu_cluster_resolver = None
    if FLAGS.use_tpu and FLAGS.tpu_name:
        tpu_cluster_resolver = tf.contrib.cluster_resolver.TPUClusterResolver(
            FLAGS.tpu_name, zone=FLAGS.tpu_zone, project=FLAGS.gcp_project)

    is_per_host = tf.contrib.tpu.InputPipelineConfig.PER_HOST_V2
    run_config = tf.contrib.tpu.RunConfig(
        cluster=tpu_cluster_resolver,
        master=FLAGS.master,
        model_dir=FLAGS.output_dir,
        save_checkpoints_steps=FLAGS.save_checkpoints_steps,
        tpu_config=tf.contrib.tpu.TPUConfig(
            iterations_per_loop=FLAGS.iterations_per_loop,
            num_shards=FLAGS.num_tpu_cores,
            per_host_input_for_training=is_per_host))

    model_fn = model_fn_builder(
        bert_config=bert_config,
        init_checkpoint=FLAGS.init_checkpoint,
        learning_rate=FLAGS.learning_rate,
        num_train_steps=FLAGS.num_train_steps,
        num_warmup_steps=FLAGS.num_warmup_steps,
        use_tpu=FLAGS.use_tpu,
        use_one_hot_embeddings=FLAGS.use_tpu)

    # lxw added test
    '''
  seqs = np.ones((1,128), dtype=np.float)
  feature = {}
  feature["input_ids"] = tf.constant(seqs, dtype=tf.int32)
  feature["input_mask"] = tf.constant(seqs, dtype=tf.int32)
  feature["segment_ids"] = tf.constant(np.zeros((1,128)), dtype=tf.int32)
  feature["masked_lm_positions"] = tf.constant(seqs, dtype=tf.int32)
  feature["masked_lm_ids"] = tf.constant(seqs, dtype=tf.int32)
  feature["masked_lm_weights"] = tf.constant(seqs, dtype=tf.int32)
  feature["next_sentence_labels"] = tf.constant([[0]], dtype=tf.int32)
  model_fn(feature,labels=None, mode=tf.estimator.ModeKeys.TRAIN,params=None)  
  '''
    # end test

    # If TPU is not available, this will fall back to normal Estimator on CPU
    # or GPU.
    estimator = tf.contrib.tpu.TPUEstimator(
        use_tpu=FLAGS.use_tpu,
        model_fn=model_fn,
        config=run_config,
        train_batch_size=FLAGS.train_batch_size,
        eval_batch_size=FLAGS.eval_batch_size)

    if FLAGS.do_train:
        tf.logging.info("***** Running training *****")
        tf.logging.info("  Batch size = %d", FLAGS.train_batch_size)
        train_input_fn = input_fn_builder(
            input_files=input_files,
            max_seq_length=FLAGS.max_seq_length,
            max_predictions_per_seq=FLAGS.max_predictions_per_seq,
            is_training=True)
        estimator.train(input_fn=train_input_fn, max_steps=FLAGS.num_train_steps)

    if FLAGS.do_eval:
        tf.logging.info("***** Running evaluation *****")
        tf.logging.info("  Batch size = %d", FLAGS.eval_batch_size)

        eval_input_fn = input_fn_builder(
            input_files=input_files,
            max_seq_length=FLAGS.max_seq_length,
            max_predictions_per_seq=FLAGS.max_predictions_per_seq,
            is_training=False)

        result = estimator.evaluate(
            input_fn=eval_input_fn, steps=FLAGS.max_eval_steps)

        output_eval_file = os.path.join(FLAGS.output_dir, "eval_results.txt")
        with tf.gfile.GFile(output_eval_file, "w") as writer:
            tf.logging.info("***** Eval results *****")
            for key in sorted(result.keys()):
                tf.logging.info("  %s = %s", key, str(result[key]))
                writer.write("%s = %s\n" % (key, str(result[key])))


if __name__ == "__main__":
    flags.mark_flag_as_required("input_file")
    flags.mark_flag_as_required("bert_config_file")
    flags.mark_flag_as_required("output_dir")
    tf.app.run()
