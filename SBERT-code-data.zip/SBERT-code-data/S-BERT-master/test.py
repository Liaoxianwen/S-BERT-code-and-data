# coding=utf-8

import tensorflow as tf
import tensorflow.contrib.eager as tfeager
from modeling import create_initializer
import numpy as np

tfeager.enable_eager_execution()

def get_pos_num(num):
    if num < 0:
        return -1,-1,-1

    baiwei = int(num/100)
    shiwei = int((num - baiwei*100)/10)
    gewei = num % 10


    if baiwei > 0:
        return gewei,shiwei,baiwei

    else:  # 百位为0
        if shiwei > 0:
            return gewei, shiwei, -1
        else:  # 十位为 0
            return gewei, -1, -1

    return gewei, shiwei, baiwei


def getPositionEmbedding(len=128):

    posarr = np.zeros((22,128), dtype=np.int32) # 采用十进制的位置编码方式

    for i in range(len):
        g,s,b = get_pos_num(i)
        posarr[g,i] = 1
        if s >= 0:
            posarr[s+10,i] = 1

        if b >= 0:
            posarr[b+20,i] = 1

    pos = tf.constant(posarr, dtype=tf.float32)

    return pos

arr = getPositionEmbedding(128)

print(arr)





exit(0)

with tf.variable_scope("cls/seq_relationship"):
    output_weights = tf.get_variable(
        "output_weights",
        trainable=None,
        shape=[2, 768],
        initializer=create_initializer(0.04))
    output_bias = tf.get_variable(
        "output_bias", shape=[2,768], initializer=tf.zeros_initializer())

x=tf.constant([[1,1],[2,1]],dtype= tf.float32)
y=tf.matmul(x, output_weights) + output_bias

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    sess.run(y)

    tv = tf.trainable_variables()

    print(tv)
